import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Heart, Activity, Moon, UserCircle, Stethoscope } from 'lucide-react';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import UserProfile from './pages/UserProfile';
import DoctorLogin from './pages/DoctorLogin';
import HealthTracking from './pages/HealthTracking';
import CardiacMonitoring from './pages/CardiacMonitoring';
import WellnessCenter from './pages/WellnessCenter';
import PeriodTracking from './pages/PeriodTracking';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/profile" element={<UserProfile />} />
            <Route path="/doctor-login" element={<DoctorLogin />} />
            <Route path="/health-tracking" element={<HealthTracking />} />
            <Route path="/cardiac" element={<CardiacMonitoring />} />
            <Route path="/wellness" element={<WellnessCenter />} />
            <Route path="/period-tracking" element={<PeriodTracking />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;