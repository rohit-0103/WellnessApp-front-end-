import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Heart, Activity, Moon, UserCircle, Stethoscope } from 'lucide-react';

const Navbar = () => {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path ? 'bg-blue-700' : '';
  };

  return (
    <nav className="bg-blue-600 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Heart className="w-8 h-8" />
            <span className="font-bold text-xl">HealthCare+</span>
          </Link>
          
          <div className="hidden md:flex space-x-4">
            <Link to="/health-tracking" className={`flex items-center space-x-1 px-3 py-2 rounded-md hover:bg-blue-700 ${isActive('/health-tracking')}`}>
              <Activity className="w-5 h-5" />
              <span>Health Tracking</span>
            </Link>
            
            <Link to="/cardiac" className={`flex items-center space-x-1 px-3 py-2 rounded-md hover:bg-blue-700 ${isActive('/cardiac')}`}>
              <Heart className="w-5 h-5" />
              <span>Cardiac</span>
            </Link>
            
            <Link to="/wellness" className={`flex items-center space-x-1 px-3 py-2 rounded-md hover:bg-blue-700 ${isActive('/wellness')}`}>
              <Moon className="w-5 h-5" />
              <span>Wellness</span>
            </Link>
            
            <Link to="/doctor-login" className={`flex items-center space-x-1 px-3 py-2 rounded-md hover:bg-blue-700 ${isActive('/doctor-login')}`}>
              <Stethoscope className="w-5 h-5" />
              <span>Doctor Portal</span>
            </Link>
            
            <Link to="/profile" className={`flex items-center space-x-1 px-3 py-2 rounded-md hover:bg-blue-700 ${isActive('/profile')}`}>
              <UserCircle className="w-5 h-5" />
              <span>Profile</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;