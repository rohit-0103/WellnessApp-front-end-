import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Activity, Moon, Calendar, Stethoscope } from 'lucide-react';

const Dashboard = () => {
  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to HealthCare+</h1>
        <p className="text-xl text-gray-600">Your comprehensive health and wellness companion</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DashboardCard
          title="Health Tracking"
          description="Monitor your daily activities, calories, and exercise routines"
          icon={<Activity className="w-8 h-8 text-green-500" />}
          link="/health-tracking"
          color="bg-green-50"
        />
        
        <DashboardCard
          title="Cardiac Monitoring"
          description="Track your heart health and get real-time alerts"
          icon={<Heart className="w-8 h-8 text-red-500" />}
          link="/cardiac"
          color="bg-red-50"
        />
        
        <DashboardCard
          title="Wellness Center"
          description="Access meditation guides and sleep tracking"
          icon={<Moon className="w-8 h-8 text-purple-500" />}
          link="/wellness"
          color="bg-purple-50"
        />
        
        <DashboardCard
          title="Period Tracking"
          description="Track your menstrual cycle and fertility window"
          icon={<Calendar className="w-8 h-8 text-pink-500" />}
          link="/period-tracking"
          color="bg-pink-50"
        />
        
        <DashboardCard
          title="Doctor Portal"
          description="Secure login for healthcare professionals"
          icon={<Stethoscope className="w-8 h-8 text-blue-500" />}
          link="/doctor-login"
          color="bg-blue-50"
        />
      </div>
    </div>
  );
};

const DashboardCard = ({ title, description, icon, link, color }: {
  title: string;
  description: string;
  icon: React.ReactNode;
  link: string;
  color: string;
}) => {
  return (
    <Link to={link}>
      <div className={`${color} p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-200`}>
        <div className="flex items-center space-x-4 mb-4">
          {icon}
          <h2 className="text-xl font-semibold text-gray-900">{title}</h2>
        </div>
        <p className="text-gray-600">{description}</p>
      </div>
    </Link>
  );
};

export default Dashboard;