import React from 'react';
import { Heart, AlertCircle, Activity, Clock } from 'lucide-react';

const CardiacMonitoring = () => {
  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Cardiac Monitoring</h1>
        <p className="text-gray-600 mt-2">Real-time heart health tracking and analysis</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <Heart className="w-6 h-6 text-red-500" />
            <h2 className="text-lg font-semibold text-gray-800">Heart Rate</h2>
          </div>
          <p className="text-3xl font-bold text-gray-900">72 BPM</p>
          <p className="text-sm text-gray-600 mt-2">Normal range</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <Activity className="w-6 h-6 text-blue-500" />
            <h2 className="text-lg font-semibold text-gray-800">Blood Pressure</h2>
          </div>
          <p className="text-3xl font-bold text-gray-900">120/80</p>
          <p className="text-sm text-gray-600 mt-2">Optimal</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <Clock className="w-6 h-6 text-green-500" />
            <h2 className="text-lg font-semibold text-gray-800">Last Reading</h2>
          </div>
          <p className="text-3xl font-bold text-gray-900">5m ago</p>
          <p className="text-sm text-gray-600 mt-2">Updated regularly</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <AlertCircle className="w-6 h-6 text-yellow-500" />
            <h2 className="text-lg font-semibold text-gray-800">Status</h2>
          </div>
          <p className="text-3xl font-bold text-green-500">Normal</p>
          <p className="text-sm text-gray-600 mt-2">All metrics stable</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Daily Medication Schedule</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
              <div>
                <p className="font-medium text-gray-800">Aspirin</p>
                <p className="text-sm text-gray-600">81mg</p>
              </div>
              <p className="text-sm text-gray-600">8:00 AM</p>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
              <div>
                <p className="font-medium text-gray-800">Metoprolol</p>
                <p className="text-sm text-gray-600">25mg</p>
              </div>
              <p className="text-sm text-gray-600">9:00 PM</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Recent Alerts</h2>
          <div className="space-y-4">
            <div className="flex items-center space-x-4 p-3 bg-green-50 rounded-md">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <p className="text-sm text-gray-800">Heart rate returned to normal range</p>
              <p className="text-sm text-gray-500">2h ago</p>
            </div>
            <div className="flex items-center space-x-4 p-3 bg-yellow-50 rounded-md">
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <p className="text-sm text-gray-800">Slightly elevated blood pressure</p>
              <p className="text-sm text-gray-500">5h ago</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardiacMonitoring;