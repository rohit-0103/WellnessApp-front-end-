import React from 'react';
import { Calendar, Clock, Droplet, AlertCircle } from 'lucide-react';

const PeriodTracking = () => {
  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Period Tracking</h1>
        <p className="text-gray-600 mt-2">Monitor your menstrual cycle and fertility window</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <Calendar className="w-6 h-6 text-pink-500" />
            <h2 className="text-lg font-semibold text-gray-800">Next Period</h2>
          </div>
          <p className="text-3xl font-bold text-gray-900">12 days</p>
          <p className="text-sm text-gray-600 mt-2">March 15, 2024</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <Clock className="w-6 h-6 text-purple-500" />
            <h2 className="text-lg font-semibold text-gray-800">Cycle Length</h2>
          </div>
          <p className="text-3xl font-bold text-gray-900">28 days</p>
          <p className="text-sm text-gray-600 mt-2">Regular cycle</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <Droplet className="w-6 h-6 text-blue-500" />
            <h2 className="text-lg font-semibold text-gray-800">Fertile Window</h2>
          </div>
          <p className="text-3xl font-bold text-gray-900">5 days</p>
          <p className="text-sm text-gray-600 mt-2">March 3-7, 2024</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <AlertCircle className="w-6 h-6 text-yellow-500" />
            <h2 className="text-lg font-semibold text-gray-800">Phase</h2>
          </div>
          <p className="text-3xl font-bold text-gray-900">Luteal</p>
          <p className="text-sm text-gray-600 mt-2">Day 16 of cycle</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Symptoms Log</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <p className="text-gray-800">Cramps</p>
              </div>
              <p className="text-sm text-gray-600">Mild</p>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <p className="text-gray-800">Mood</p>
              </div>
              <p className="text-sm text-gray-600">Stable</p>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <p className="text-gray-800">Energy</p>
              </div>
              <p className="text-sm text-gray-600">Medium</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Recommendations</h2>
          <div className="space-y-4">
            <div className="p-3 bg-pink-50 rounded-md">
              <h3 className="font-medium text-gray-800 mb-1">Exercise</h3>
              <p className="text-sm text-gray-600">Light to moderate exercise recommended</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-md">
              <h3 className="font-medium text-gray-800 mb-1">Diet</h3>
              <p className="text-sm text-gray-600">Increase iron-rich foods intake</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-md">
              <h3 className="font-medium text-gray-800 mb-1">Self-Care</h3>
              <p className="text-sm text-gray-600">Consider taking a warm bath for cramp relief</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PeriodTracking;