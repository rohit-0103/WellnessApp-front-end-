import React from 'react';
import { useForm } from 'react-hook-form';
import { Stethoscope } from 'lucide-react';

type DoctorLoginForm = {
  licenseNumber: string;
  email: string;
  password: string;
};

const DoctorLogin = () => {
  const { register, handleSubmit } = useForm<DoctorLoginForm>();

  const onSubmit = (data: DoctorLoginForm) => {
    console.log(data);
    // Handle login submission
  };

  return (
    <div className="max-w-md mx-auto mt-8">
      <div className="text-center mb-8">
        <div className="inline-block p-3 rounded-full bg-blue-100 mb-4">
          <Stethoscope className="w-8 h-8 text-blue-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">Doctor Portal</h1>
        <p className="text-gray-600 mt-2">Access your healthcare dashboard</p>
      </div>

      <div className="bg-white p-8 rounded-lg shadow-sm">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Medical License Number
            </label>
            <input
              type="text"
              {...register('licenseNumber')}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              placeholder="Enter your license number"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email Address
            </label>
            <input
              type="email"
              {...register('email')}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              placeholder="doctor@example.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Password
            </label>
            <input
              type="password"
              {...register('password')}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Sign In
          </button>
        </form>

        <div className="mt-6 text-center">
          <a href="#" className="text-sm text-blue-600 hover:text-blue-800">
            Forgot your password?
          </a>
        </div>
      </div>

      <div className="mt-6 text-center">
        <p className="text-sm text-gray-600">
          New to HealthCare+?{' '}
          <a href="#" className="text-blue-600 hover:text-blue-800">
            Register as a healthcare provider
          </a>
        </p>
      </div>
    </div>
  );
};

export default DoctorLogin;