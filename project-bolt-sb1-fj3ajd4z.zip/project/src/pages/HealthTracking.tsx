import React from 'react';
import { Activity, Utensils, Heart } from 'lucide-react';

const HealthTracking = () => {
  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Health Tracking</h1>
        <p className="text-gray-600 mt-2">Monitor your daily activities and health metrics</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <Activity className="w-6 h-6 text-green-500" />
            <h2 className="text-xl font-semibold text-gray-800">Daily Activity</h2>
          </div>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600">Steps Today</p>
              <p className="text-2xl font-bold text-gray-900">8,439</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Distance</p>
              <p className="text-2xl font-bold text-gray-900">5.2 km</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <Utensils className="w-6 h-6 text-blue-500" />
            <h2 className="text-xl font-semibold text-gray-800">Nutrition</h2>
          </div>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600">Calories Consumed</p>
              <p className="text-2xl font-bold text-gray-900">1,840</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Water Intake</p>
              <p className="text-2xl font-bold text-gray-900">1.5 L</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <Heart className="w-6 h-6 text-red-500" />
            <h2 className="text-xl font-semibold text-gray-800">Vitals</h2>
          </div>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600">Heart Rate</p>
              <p className="text-2xl font-bold text-gray-900">72 bpm</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Blood Pressure</p>
              <p className="text-2xl font-bold text-gray-900">120/80</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Activity Timeline</h2>
        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <p className="text-sm text-gray-600">Morning Walk - 30 minutes</p>
            <p className="text-sm text-gray-500">8:00 AM</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            <p className="text-sm text-gray-600">Yoga Session - 45 minutes</p>
            <p className="text-sm text-gray-500">10:30 AM</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
            <p className="text-sm text-gray-600">Evening Run - 5 km</p>
            <p className="text-sm text-gray-500">6:00 PM</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HealthTracking;