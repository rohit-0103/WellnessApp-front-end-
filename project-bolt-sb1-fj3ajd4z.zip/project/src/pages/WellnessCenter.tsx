import React from 'react';
import { Moon, Sun, Wind, Music } from 'lucide-react';

const WellnessCenter = () => {
  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Wellness Center</h1>
        <p className="text-gray-600 mt-2">Your daily guide to mental and physical wellness</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-6">
            <Moon className="w-6 h-6 text-purple-500" />
            <h2 className="text-xl font-semibold text-gray-800">Sleep Analysis</h2>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <p className="text-gray-600">Sleep Duration</p>
              <p className="font-semibold text-gray-900">7h 30m</p>
            </div>
            <div className="flex justify-between items-center">
              <p className="text-gray-600">Sleep Quality</p>
              <p className="font-semibold text-gray-900">85%</p>
            </div>
            <div className="flex justify-between items-center">
              <p className="text-gray-600">Deep Sleep</p>
              <p className="font-semibold text-gray-900">2h 15m</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3 mb-6">
            <Wind className="w-6 h-6 text-blue-500" />
            <h2 className="text-xl font-semibold text-gray-800">Meditation Stats</h2>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <p className="text-gray-600">Today's Session</p>
              <p className="font-semibold text-gray-900">20 minutes</p>
            </div>
            <div className="flex justify-between items-center">
              <p className="text-gray-600">Weekly Goal</p>
              <p className="font-semibold text-gray-900">70%</p>
            </div>
            <div className="flex justify-between items-center">
              <p className="text-gray-600">Streak</p>
              <p className="font-semibold text-gray-900">5 days</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-xl font-semibold text-gray-800 mb-6">Meditation Sessions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-purple-50 p-4 rounded-lg">
            <Music className="w-6 h-6 text-purple-500 mb-3" />
            <h3 className="font-semibold text-gray-800 mb-2">Morning Calm</h3>
            <p className="text-sm text-gray-600 mb-4">Start your day with 10 minutes of mindfulness</p>
            <button className="w-full py-2 px-4 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors">
              Start Session
            </button>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <Sun className="w-6 h-6 text-blue-500 mb-3" />
            <h3 className="font-semibold text-gray-800 mb-2">Stress Relief</h3>
            <p className="text-sm text-gray-600 mb-4">15-minute guided breathing exercise</p>
            <button className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
              Start Session
            </button>
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <Moon className="w-6 h-6 text-green-500 mb-3" />
            <h3 className="font-semibold text-gray-800 mb-2">Sleep Better</h3>
            <p className="text-sm text-gray-600 mb-4">20-minute evening relaxation</p>
            <button className="w-full py-2 px-4 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
              Start Session
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WellnessCenter;